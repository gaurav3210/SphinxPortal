from django.shortcuts import render
from django.shortcuts import HttpResponse
# Create your views here.

def contest(request):
    return render(request, "choice question.html");